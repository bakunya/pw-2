<div class="container">
    <h1 class="mt-5">About Page</h1>
    <p class="lead">Selamat Datang Pada Halaman About</p>
    <p>Back to <a href="#">the default sticky footer by </a> firman_asharudin@amikom.ac.id.</p>
</div>