<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function index()
    {
        $this->load->view('_partials/head.php');
        $this->load->view('_partials/nav.php');
        $this->load->view('user/index.php');
        $this->load->view('_partials/footer.php');
    }

    public function about()
    {
        $this->load->view('_partials/head.php');
        $this->load->view('_partials/nav.php');
        $this->load->view('user/about.php');
        $this->load->view('_partials/footer.php');
    }
}
