<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<?php if(isset($js)): ?>
    <?php foreach($js as $j): ?>
        <script src="<?= base_url($j) ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>
</body>
</html>