<?php

namespace application\traits;

trait template
{
    public function load(array $files): void
    {
        foreach ($files as $f) {
            $this->load->view($f);
        }
    }
}
